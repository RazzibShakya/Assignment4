
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
var passport = require('passport');
require('./Model/mongoose');
const User = require('./Model/User');
const Item = require('./Model/Item')
const app = express();
const path = require('path');
const multer = require('multer')
app.use(express.json());
app.use(cors());


app.use('/4thassignment/images',express.static('./images'));

app.use(bodyParser.urlencoded({ extended: false }));

var storage = multer.diskStorage({
    destination: "images", //this is folder name
    filename: function (req, file, callback)
    {
    const ext = path.extname(file.originalname); //.js,.pdf etc extenstion linchha
    callback(null, "ram" + Date.now() + ext); //renaming file
    }
   
    });

    //this if for validating image files
    var imageFileFilter = (req, file, cb) => {if
        (!file.originalname.match(/\.(jpg|jpeg|png|gif|JPG|PNG)$/))
         {return cb(("You can upload only image files!"), false); }
         cb(null, true);};
        
         var upload = multer({
         storage: storage,
         fileFilter: imageFileFilter,
         limits: { fileSize: 10000000
         }});

           

app.post('/4thassignment/createuser', (req, res) => {
    console.log(req.body);
    var mydata = new User(req.body);

    mydata.save().then(function () {
        res.send('User successfully registered');
    }).catch(function (e) {
        res.send(e);

    });
});

app.post('/4thassignment/userlogin', (req, res) => {
  var Username=req.body.username;
  var Password=req.body.password;
console.log(req.body);
  User.findOne({username:Username,password:Password}).then(function(user){
      console.log(user);
    if(user){
        res.json("Successfully");
    }else{
        res.json("Your user does not exist")
    }
    
  })
  
  })
  
  


app.post('/4thassignment/additem', (req, res) => { //add Item
    console.log(req.body);
    var item = new Item(req.body);

    item.save().then(function () {
        res.send('fine');
    }).catch(function (e) {
        res.send(e);

    });
});
app.get('/4thassignment/displayUser', function (req, res) {
    User.find().then(function (user) {
        res.send(user);
    }).catch(function (e) {
        res.send(e)
    });

});
app.get('/4thassignment/displayitem', function (req, res) {   //get data of Items
    Item.find().then(function (item) {
        res.send(item);
    }).catch(function (e) {
        res.send(e)
    });
});
app.post('/4thassignment/uploadpic', upload.single('files'), (req, res) => {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.json(req.file);

})  

app.listen(3000);
